package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Userprofile extends AppCompatActivity {



    String ems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        getSupportActionBar().setTitle("PROFILE");

        Intent intent =getIntent();
        ems =intent.getStringExtra("email");


        BottomNavigationView bottomNavigationView =findViewById(R.id.bottomprofile);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Bswitch(menuItem);
                return false;
            }
        });

        //display data
        exEverything();


    }




    public  boolean Bswitch(MenuItem menuItem){

        switch (menuItem.getItemId()){

            case R.id.homee:
                Intent intent = new Intent(Userprofile.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                return true;

            case R.id.editp:
                Intent intent12 = new Intent(Userprofile.this,Editprofile.class);
                intent12.putExtra("email",ems);
                startActivity(intent12);
                return true;

            default:
                return  false;

        }


    }





    public  void  exEverything(){

        final TextView t = (TextView)findViewById(R.id.displayinfo);

        ContentValues params = new ContentValues();
        params.put("email",ems);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/kuserinfo.php",params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;
                try{
                    T = new JSONArray(output);
                    int a =T.length();
                    String Arr1[] = new String[a];


                    for(int i =0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = " "+"first names  :  "+Aw.get("name")+"\n"+"\n"+"\n"+"surname     :  "+" "+Aw.get("identity")+"\n"+"\n"+"\n"
                                +"email         :  "+" "+Aw.get("email") +"\n"+"\n"+"\n"+"gender       : "+Aw.get("gender")+"\n"+"\n"+"\n"+"\n";
                        Arr1[i]=some;
                    }

                    String fn="";

                    for(int i=0;i<Arr1.length;i++){

                        fn = fn + Arr1[i]+"\n";
                    }

                    t.setText(fn);

                }
                catch(JSONException k){k.printStackTrace();}



            }
        };
        asyncHTTPPost.execute();

    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.sideprofile,menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.viewbio:
                Intent intent2 = new Intent(Userprofile.this,Viewbioo.class);
                intent2.putExtra("email",ems);
                startActivity(intent2);

                return true;


            case R.id.editbio:
                Intent intent23 = new Intent(Userprofile.this,Editbioo.class);
                intent23.putExtra("email",ems);
                startActivity(intent23);

                return true;

            default:
                return super.onOptionsItemSelected(item);


        }


    }








}
