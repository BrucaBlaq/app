package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Donated extends AppCompatActivity {


    String ems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donated);
        getSupportActionBar().setTitle("items you donated");


        Intent intent =getIntent();
        ems =intent.getStringExtra("email");








        final TextView t = (TextView)findViewById(R.id.displayinfo);
        ContentValues params = new ContentValues();
        params.put("email",ems);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/yourdonation.php",params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;
                try{
                    T = new JSONArray(output);
                    int a =T.length();
                    String Arr1[] = new String[a];


                    for(int i =0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = "you donated item of this id  :"+" "+Aw.get("itemid")+"\n"+"to this user :  "+" "+Aw.get("remail")+"\n"+"date :  "+" "+Aw.get("time")+"\n"+"\n"+"\n"+"  ";
                        Arr1[i]=some;
                    }

                    String fn="";

                    for(int i=Arr1.length-1;i>=0;i--){

                        fn = fn + Arr1[i]+"\n";
                    }

                    t.setText(fn);

                }
                catch(JSONException k){k.printStackTrace();}



            }
        };
        asyncHTTPPost.execute();









        BottomNavigationView bottomNavigationView =findViewById(R.id.bottommenu);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Bswitch(menuItem);
                return false;
            }
        });






    }



    public  boolean Bswitch(MenuItem menuItem){

        switch (menuItem.getItemId()){

            case R.id.his:
                Intent intent = new Intent(Donated.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                return true;


            default:
                return  false;

        }


    }


}
