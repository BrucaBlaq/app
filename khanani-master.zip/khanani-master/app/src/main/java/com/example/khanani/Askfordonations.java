package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Askfordonations extends AppCompatActivity implements View.OnClickListener {
    String Arr1[];
    String ems;
    Button ad;
    EditText askd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_askfordonations);
        getSupportActionBar().setTitle("ask for donation");

        ad =(Button)findViewById(R.id.add);
        askd =(EditText)findViewById(R.id.askitems);

        ad.setOnClickListener(this);
        Intent intent =getIntent();
        ems =intent.getStringExtra("email");


        final TextView t = (TextView)findViewById(R.id.displayinfo);
        ContentValues params = new ContentValues();
        params.put("email",ems);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/kdisplayyourneeds.php",params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;
                try{
                    T = new JSONArray(output);
                    int a =T.length();
                    String Arr1[] = new String[a];


                    for(int i =0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = "im in need of  "+Aw.get("needs")+"\n"+"item id  :  "+" "+Aw.get("itemid")+"\n"+"date posted :  "+" "+Aw.get("time")+"\n"+"\n"+"\n"+"  ";
                        Arr1[i]=some;
                    }

                    String fn="";

                    for(int i=Arr1.length-1;i>=0;i--){

                        fn = fn + Arr1[i]+"\n";
                    }

                    t.setText(fn);

                }
                catch(JSONException k){k.printStackTrace();}



            }
        };
        asyncHTTPPost.execute();
















        exTHING();




        BottomNavigationView bottomNavigationView =findViewById(R.id.bottommenu);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Bswitch(menuItem);
                return false;
            }
        });




    }

    @Override
    public void onClick(View v) {
        if(v.equals(ad)){
            String askdonation = askd.getText().toString().trim();
            boolean st = true;
            if(askdonation.equals("")){
                askd.setError("this can not be empty");
                st = false;
            }
            else if(st == true){

                ArrayList<String>a = new ArrayList<>();
                for(int i=0;i<Arr1.length;i++){
                  a.add(Arr1[i]);
                }

                //select all the items id  store them in a list,create new itemid check its uique,
                //



                String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                Random rnd = new Random();

                //item id
                String aa="";
                int abc =0;
                for (int i = 0; i < 1000; i++) {
                    //int aa = (int)(Math.random()*10);

                    StringBuilder sb = new StringBuilder( 8 );
                    for( int ii = 0; ii < 8; ii++ ) {
                        sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );}

                    aa = sb.toString();
                    boolean state = true;
                    for (int j = 0; j < a.size(); j++) {
                        if (a.get(j) ==aa ) {
                            state	 =false;
                            break;

//a[j] = (int)(Math.random()*10); //What's this! Another random number!
                        }
                    }

                    if(state == true){
                        abc =1;
                        //a.add(aa);
                        break;
                    }

                }


                if(abc == 1) {
                    //email ems,itemid=aa,wat the person is looking for =askdonation;
                    //push everything to database
                    String  mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                    String type ="reg";
                    backdonation backgroundTask = new backdonation(getApplicationContext(),"");
                    backgroundTask.execute(type, ems, aa,askdonation,mydate);
                    askd.setText("");
                    Intent intent = new Intent(Askfordonations.this,Homepage.class);
                    intent.putExtra("email",ems);
                    startActivity(intent);




                }



            }




        }

    }



public void exTHING(){




    //final TextView t = (TextView)findViewById(R.id.displayinfo);
    ContentValues params = new ContentValues();
    params.put("email",ems);

    AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/selectitemid.php",params) {
        @Override
        protected void onPostExecute(String output) {

            JSONArray T = null;
            try{
                T = new JSONArray(output);
                int a =T.length();
                Arr1 = new String[a];


                for(int i =0;i<T.length();i++){
                    String some="";
                    JSONObject Aw =(JSONObject)T.get(i);

                    some = Aw.get("itemid")+"";
                    Arr1[i]=some;
                }


                //t.setText(fn);

            }
            catch(JSONException k){k.printStackTrace();}



        }
    };
    asyncHTTPPost.execute();









}



    public  boolean Bswitch(MenuItem menuItem){

        switch (menuItem.getItemId()){

            case R.id.his:
                Intent intent = new Intent(Askfordonations.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                return true;


            default:
                return  false;

        }


    }






}
