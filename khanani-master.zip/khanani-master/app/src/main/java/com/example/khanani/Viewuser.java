package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Viewuser extends AppCompatActivity implements View.OnClickListener{


    String ems;
    Button st;
    EditText a ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewuser);
        getSupportActionBar().setTitle("view users");

        Intent intent =getIntent();
        ems =intent.getStringExtra("email");

        a =(EditText)findViewById(R.id.emaill);
        st =(Button)findViewById(R.id.search);



        st.setOnClickListener(this);


        BottomNavigationView bottomNavigationView =findViewById(R.id.bottommenu);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Bswitch(menuItem);
                return false;
            }
        });




    }









    public  boolean Bswitch(MenuItem menuItem){

        switch (menuItem.getItemId()){

            case R.id.his:
                Intent intent = new Intent(Viewuser.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                return true;


            default:
                return  false;

        }


    }


    @Override
    public void onClick(View v) {
        if(v.equals(st)){

            String em = a.getText().toString().trim();
            if(verify(em) == true){
                stEVER(em);

            }

        }
    }


    public boolean verify(String aa){
        boolean st = true;
        if(aa.equals("")){
            st = false;
            a.setError("please input user email address");

        }

        return st;
    }




    public void stEVER(String emmmm){


        //do search

        String ad="http://10.100.15.37/userbio.php";
        ContentValues params= new ContentValues();
        params.put("email",emmmm);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost(ad,params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;

                try{


                    T = new JSONArray(output);
                    int aa= T.length();
                    String Arr1[] = new String[aa];

                    for(int i=0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = Aw.get("bio")+"\n"+"\n";
                        Arr1[i] =some;

                    }


                    TextView inforBOOKS=(TextView) findViewById(R.id.displayinfo);
                    String pr="";
                    for(int i =0;i<Arr1.length;i++){
                        pr += Arr1[i]+"\n";

                    }
                    if(pr.equals("")){
                        inforBOOKS.setText("user does not exist");
                    }
                    else {   inforBOOKS.setText(pr);}

                }
                catch (JSONException k){

                    k.printStackTrace();
                }






            }
        };

        asyncHTTPPost.execute();




    }


}
