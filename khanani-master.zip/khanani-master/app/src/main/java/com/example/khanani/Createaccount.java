package com.example.khanani;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Createaccount extends AppCompatActivity implements View.OnClickListener{

    TextView a,b,c,d,e,lg;
    String nnn="";
    Button cre;
    String na,sur,em,ps,pss;
    //sur = identity number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createaccount);

        getSupportActionBar().setTitle("CREATE ACCOUNT");
        lg=(TextView)findViewById(R.id.loginini);
        a =(TextView)findViewById(R.id.names);
        b =(TextView)findViewById(R.id.iden);
        c =(TextView)findViewById(R.id.emailA);
        d =(TextView)findViewById(R.id.pass);
        e=(TextView)findViewById(R.id.confirm);
        cre =(Button)findViewById(R.id.createA);


        cre.setOnClickListener(this);
        lg.setOnClickListener(this);




    }

    @Override
    public void onClick(View v) {

        if(v.equals(lg)){

            Intent intent = new Intent(Createaccount.this,Login.class);
            startActivity(intent);
        }

        if(v.equals(cre)){

            takeinput();
            if(verifyinput(na,sur,em,ps,pss,nnn) ==  1){

                String type ="reg";
                BackgroundTask backgroundTask = new BackgroundTask(getApplicationContext(),"");
                backgroundTask.execute(type, na, sur, em,nnn, ps);

                a.setText("");
                b.setText("");
                c.setText("");
                d.setText("");
                e.setText("");




            }




        }



    }

    public  int verifyinput(String na,String sur,String em,String ps,String pss,String nnn){


        int state = 1;
        if(na.equals("")){
            state = 0;
            a.setError("please input name(s)");
        }
        if(sur.equals("")){
            state = 0;
            b.setError("surname can not be empty");
        }
        if(em.equals("")){
            state = 0;
            c.setError("email address can not be empty");
        }
        if(ps.equals("")){
            state = 0;
            d.setError("password can not be empty");
        }

        if(!pss.equals(ps)){
            state = 0;
            e.setError("password did not match");

        }
        if(nnn.equals("")){
            Toast.makeText(getApplicationContext(),"please select your gender",Toast.LENGTH_SHORT).show();
            state = 0;
        }




        return state;
    }


    public void takeinput(){

        na = a.getText().toString();
        sur =b.getText().toString();
        em  =c.getText().toString();
        ps =d.getText().toString();
        pss=e.getText().toString();



    }



    public void dogen(View v){
        boolean checked =((RadioButton) v).isChecked();
        switch (v.getId()){
            case R.id.male:
                nnn = "Male";
                break;

            case R.id.female:
                nnn ="Female";
                break;
        }

    }




}
