package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class Homepage extends AppCompatActivity implements View.OnClickListener {

    String ems;
    Button dt;
    EditText a,bb;
    String Arr12[];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        getSupportActionBar().setTitle("HOMEPAGE");


        BottomNavigationView bottomNavigationView =findViewById(R.id.bottommenu);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {


                bswitch(menuItem);
                return  false;

            }
        });




        Intent intent =getIntent();
        ems =intent.getStringExtra("email");
        dt =(Button)findViewById(R.id.donate);
        a =(EditText) findViewById(R.id.itemidd);
        bb =(EditText)findViewById(R.id.remails);
        dt.setOnClickListener(this);
        exTHING();



    }





    public boolean bswitch(MenuItem menuItem)
    {


        switch (menuItem.getItemId()) {






            case R.id.profileee:
                Intent intent = new Intent(Homepage.this,Userprofile.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                // overridePendingTransition(0,0);
                return true;



            case R.id.reciver:
                Intent intent111 = new Intent(Homepage.this,Itemsrecived.class);
                intent111.putExtra("email",ems);
                startActivity(intent111);
                // overridePendingTransition(0,0);
                return true;





            case R.id.out:


                Intent intent11 = new Intent(Homepage.this, Createaccount.class);
                Toast.makeText(getApplicationContext(),"goodbye",Toast.LENGTH_SHORT).show();
                startActivity(intent11);


                return true;


            case R.id.busket:
                Intent intent1 = new Intent(Homepage.this, Donated.class);
                intent1.putExtra("email", ems);
                startActivity(intent1);
                //overridePendingTransition(0,0);
                return true;



            default:
                return  false;
        }





    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.sidemenu,menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.ask:
                Intent intent2 = new Intent(Homepage.this,Askfordonations.class);
                intent2.putExtra("email",ems);
                startActivity(intent2);

                return true;


            case R.id.viewuser:
                Intent intent23 = new Intent(Homepage.this,Viewuser.class);
                intent23.putExtra("email",ems);
                startActivity(intent23);

                return true;

            default:
                return super.onOptionsItemSelected(item);


        }


    }


    public void exTHING(){




        final TextView t = (TextView)findViewById(R.id.displayinfo);
        ContentValues params = new ContentValues();
        params.put("email",ems);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/selectitemid.php",params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;
                try{
                    T = new JSONArray(output);
                    int a =T.length();
                    String Arr1[] = new String[a];


                    for(int i =0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = "email  address    :  "+Aw.get("email")+"\n"+"im in need of   "+" "+Aw.get("needs")+"\n"+"item id   : "+Aw.get("itemid")+"\n"+"date posted  : "+Aw.get("time")+"\n"+"\n"+"\n"+"  ";
                        Arr1[i]=some;
                    }

                    String fn="";

                    for(int i=Arr1.length-1;i>=0;i--){

                        fn = fn + Arr1[i]+"\n";
                    }

                    t.setText(fn);




                }
                catch(JSONException k){k.printStackTrace();}



            }
        };
        asyncHTTPPost.execute();









    }


    public boolean verify(String aa,String aaa){
        boolean st = true;
        if(aa.equals("")){
            st = false;
            a.setError("please type in what you want to donate");

        }
        if(aaa.equals("")){
            st =false;
            bb.setError("receiver email cannot be empty");

        }

        return st;
    }


    @Override
    public void onClick(View v) {
        if(v.equals(dt)){

            String wdt = a.getText().toString().trim();
            String rem =bb.getText().toString().trim();
            if(verify(wdt,rem) == true){
                //newthing(wdt);



                String  mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
                String type ="reg";
                backdonated backgroundTask = new backdonated(getApplicationContext(),"");
                backgroundTask.execute(type, ems,wdt,mydate,rem);
                a.setText("");


            }



        }
    }






  /*  public void newthing(String itemid){




        //final TextView t = (TextView)findViewById(R.id.displayinfo);
        ContentValues params = new ContentValues();
        params.put("email",itemid);

        AsyncHTTPPost asyncHTTPPost = new AsyncHTTPPost("http://10.100.15.37/selectremail.php",params) {
            @Override
            protected void onPostExecute(String output) {

                JSONArray T = null;
                try{
                    T = new JSONArray(output);
                    int a =T.length();
                    Arr12 = new String[a];


                    for(int i =0;i<T.length();i++){
                        String some="";
                        JSONObject Aw =(JSONObject)T.get(i);

                        some = Aw.get("email")+"";
                        Arr12[i]=some;
                    }


                    //t.setText(fn);

                }
                catch(JSONException k){k.printStackTrace();}



            }
        };
        asyncHTTPPost.execute();









    }

*/


}
