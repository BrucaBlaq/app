package com.example.khanani;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Editbioo extends AppCompatActivity implements View.OnClickListener{

    String ems;
    EditText a;
    Button up;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editbioo);

        getSupportActionBar().setTitle("UPDATE BIOGRAPHY");
        Intent intent =getIntent();
        ems =intent.getStringExtra("email");

        up =(Button)findViewById(R.id.update);
        a =(EditText) findViewById(R.id.displayinfo);

        up.setOnClickListener(this);
        BottomNavigationView bottomNavigationView =findViewById(R.id.bottommenu);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                Bswitch(menuItem);
                return false;
            }
        });



    }

    @Override
    public void onClick(View v) {

        if(v.equals(up)){
            String bio = a.getText().toString().trim();
            if(verify(bio) == true){
                String type ="reg";
                backbioupdate backgroundTask = new backbioupdate(getApplicationContext(),"");
                backgroundTask.execute(type, ems,bio);

                a.setText("");
                Intent intent = new Intent(Editbioo.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);



            }


        }


    }


    public boolean verify(String aa){
        boolean st = true;
        if(aa.equals("")){
            st  = false;
            a.setError("this can not be empty");
        }

        return  st;
    }


    public  boolean Bswitch(MenuItem menuItem){

        switch (menuItem.getItemId()){

            case R.id.his:
                Intent intent = new Intent(Editbioo.this,Homepage.class);
                intent.putExtra("email",ems);
                startActivity(intent);
                return true;


            default:
                return  false;

        }


    }




}
